CREATE DEFINER=`root`@`localhost` FUNCTION `get_driver_name`(driver_id INT) RETURNS varchar(90) CHARSET utf8mb3
    DETERMINISTIC
BEGIN
DECLARE first_name VARCHAR(45);
    DECLARE last_name VARCHAR(45);
    SELECT `first_name`, `last_name` INTO first_name, last_name FROM `FastPark`.`driver` WHERE `driver_id` = driver_id;
    RETURN CONCAT(first_name, ' ', last_name);
END