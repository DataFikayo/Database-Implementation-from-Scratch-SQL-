CREATE DEFINER=`root`@`localhost` FUNCTION `calculate_total_fee`(parking_fee INT, hours_used DECIMAL(4,2)) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
DECLARE total_fee DECIMAL(10,2);
    SET total_fee = parking_fee * hours_used;
    RETURN total_fee;
END