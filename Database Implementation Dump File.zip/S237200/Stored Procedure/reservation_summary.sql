CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reservation_summary`(IN reservation_date DATE)
BEGIN
SELECT COUNT(*) AS num_reservations, SUM(parking_fee * hours_used) AS total_revenue
	FROM reservation
	JOIN parking_space ON reservation.parking_space_id = parking_space.parking_space_id
	WHERE date = reservation_date;
END