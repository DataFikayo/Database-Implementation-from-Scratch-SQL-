CREATE PROCEDURE `get_spaces_by_owner_id` (IN owner_id INT)
BEGIN
SELECT parking_space_id, parking_fee, access_code, charging, house_number, street_name, post_code
	FROM parking_space
	JOIN parking_address ON parking_space.parking_space_id = parking_address.parking_space_id
	WHERE owner_id = owner_id;
END
