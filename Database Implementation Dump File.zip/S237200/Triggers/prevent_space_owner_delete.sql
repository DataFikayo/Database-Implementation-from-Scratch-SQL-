CREATE DEFINER=`root`@`localhost` TRIGGER `prevent_space_owner_delete` BEFORE DELETE ON `space_owner` FOR EACH ROW BEGIN
IF EXISTS(SELECT 1 FROM parking_space WHERE owner_id = OLD.owner_id AND parking_space_id IN (SELECT parking_space_id FROM reservation))
    THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete space owner as they own parking spaces with active reservations.';
    END IF;
END