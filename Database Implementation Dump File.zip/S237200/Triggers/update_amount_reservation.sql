CREATE DEFINER=`root`@`localhost` TRIGGER `populate_payment_amount` AFTER INSERT ON `reservation` FOR EACH ROW BEGIN
	DECLARE fee DECIMAL(4,2);
	DECLARE hours DECIMAL(4,2);
    DECLARE total DECIMAL(6,2);

    SELECT parking_fee INTO fee FROM parking_space WHERE parking_space_id = NEW.parking_space_id;
    SELECT hours_used INTO hours FROM reservation WHERE reservation_id = NEW.reservation_id;
    SET total = fee * hours;

    INSERT INTO payment(reservation_id, amount) VALUES (NEW.reservation_id, total);
END