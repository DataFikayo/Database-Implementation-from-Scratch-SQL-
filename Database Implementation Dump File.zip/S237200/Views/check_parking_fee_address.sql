CREATE VIEW check_parking_fee AS
select p.parking_space_id, p.parking_fee, a.post_code, a.street_name
from parking_space as p
join parking_address as a
on p.parking_space_id = a.parking_space_id;

