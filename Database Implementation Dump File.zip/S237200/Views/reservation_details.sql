CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `fastpark`.`reservation_details` AS
    SELECT 
        `r`.`reservation_id` AS `reservation_id`,
        `d`.`first_name` AS `driver_first_name`,
        `d`.`last_name` AS `driver_last_name`,
        `a`.`house_number` AS `house_number`,
        `a`.`street_name` AS `street_name`,
        `a`.`post_code` AS `post_code`,
        `p`.`parking_fee` AS `parking_fee`
    FROM
        (((`fastpark`.`reservation` `r`
        JOIN `fastpark`.`driver` `d` ON ((`r`.`driver_id` = `d`.`driver_id`)))
        JOIN `fastpark`.`parking_space` `p` ON ((`r`.`parking_space_id` = `p`.`parking_space_id`)))
        JOIN `fastpark`.`parking_address` `a` ON ((`p`.`parking_space_id` = `a`.`parking_space_id`)))